package com.niit.fashioncart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.fashioncart.dao.ProductsDAO;
import com.niit.fashioncart.dao.UserDAO;
import com.niit.fashioncart.model.Products;
import com.niit.fashioncart.model.User;


@Controller 
public class ProductsController
{

	@Autowired
	ProductsDAO productsDAO;
	
	@Autowired
	Products products;	
	
	@RequestMapping("/products")
	public ModelAndView getProducts(Model m)
	{
		m.addAttribute("products",new Products());
		ModelAndView model= new ModelAndView("products");
		return model;
	}
	@RequestMapping(value="products/add", method=RequestMethod.POST)
	public String addProducts(Model model, @ModelAttribute("products")Products products)
	{
		productsDAO.addProducts(products);
		return "redirect:/";
	}	
}