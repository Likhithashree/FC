package com.niit.fashioncart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.fashioncart.dao.SupplierDAO;
import com.niit.fashioncart.dao.UserDAO;
import com.niit.fashioncart.model.Supplier;
import com.niit.fashioncart.model.User;


@Controller 
public class SupplierController
{

	@Autowired
	SupplierDAO supplierDAO;
	
	@Autowired
	Supplier supplier;
	
	
	@RequestMapping("/supplier")
	public ModelAndView getSupplier(Model m)
	{
		m.addAttribute("supplier",new Supplier());
		ModelAndView model= new ModelAndView("supplier");
		return model;
	}
	@RequestMapping(value="supplier/add", method=RequestMethod.POST)
	public String addSupplier(Model model, @ModelAttribute("supplier")Supplier supplier)
	{
		supplierDAO.addSupplier(supplier);
		return "redirect:/";
	}	
}