package com.niit.fashioncart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.fashioncart.dao.CategoryDAO;
import com.niit.fashioncart.dao.UserDAO;
import com.niit.fashioncart.model.Category;
import com.niit.fashioncart.model.User;


@Controller 
public class CategoryController
{

	@Autowired
	CategoryDAO categoryDAO;
	
	@Autowired
	Category category;
	
	
	@RequestMapping("/category")
	public ModelAndView getCategory(Model m)
	{
		m.addAttribute("category",new Category());
		ModelAndView model= new ModelAndView("category");
		return model;
	}
	@RequestMapping(value="category/add", method=RequestMethod.POST)
	public String addCategory(Model model, @ModelAttribute("category")Category category)
	{
		categoryDAO.addCategory(category);
		return "redirect:/";
	}	
}