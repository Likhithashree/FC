package com.niit.fashioncart.dao;

import com.niit.fashioncart.model.User;

public interface UserDAO 
{
  public void addUser(User user);
}
